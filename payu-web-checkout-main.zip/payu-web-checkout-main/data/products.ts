import { Product } from "@/interface/product";

export const products: Product[] = [
  {
    id: 1,
    name: "Producto 1",
    amount: "100445",
    description: "producttt",
    referenceCode: "nnfasdnfa4343sd",
  },
  {
    id: 2,
    name: "Producto 2",
    amount: "20055",
    description: "fsdfsdf",
    referenceCode: "nnfasdnfas4432434d",
  },
  {
    id: 3,
    name: "Producto 3",
    amount: "30044",
    description: "fsdfsdf",
    referenceCode: "nnfasd43434nfasd",
  },
];
