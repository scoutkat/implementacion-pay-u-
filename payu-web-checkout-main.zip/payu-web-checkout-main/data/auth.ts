interface Auth {
  merchantId: string;
  accountId: string;
  apiLogin: string;
  apiKey: string;
}

export const AUTH: Auth = {
  merchantId: "508029",
  accountId: "512321",
  apiLogin: "pRRXKOl8ikMmt9u",
  apiKey: "4Vj8eK4rloUd272L48hsrarnUA",
};
