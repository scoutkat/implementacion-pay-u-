import PayUConfig from "@/components/payU/payU_config";

const ProductsPage: React.FC = () => {
  return <PayUConfig />;
};

export default ProductsPage;
